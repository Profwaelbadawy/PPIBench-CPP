#!/usr/bin/env bash
set -euo pipefail
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j
./build/ppibench --input data/sample_cases.csv --output sample_results.csv --split test --export-wkt sample_boolean_outputs.csv
