# PPIBench C++ Reference Implementation

C++17 reference code associated with the polygon--polygon intersection systematic review and the PPIBench-V1 IEEE DataPort dataset (DOI: 10.21227/h3yj-6020).

## Features
- Reads PPIBench CSV/WKT polygon pairs.
- Computes intersection, union, difference, and symmetric difference.
- Records per-operation execution times and output areas.
- Validates Boolean output geometries.
- Filters official train/validation/test splits.
- Optionally exports Boolean-result WKT.

## Dependencies
- CMake 3.16+
- C++17 compiler
- Boost.Geometry headers

## Build
```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j
```

## Example
```bash
./build/ppibench --input data/sample_cases.csv --output sample_results.csv --split test --export-wkt sample_boolean_outputs.csv
```

## Dataset columns
Required: `case_id`, `wkt_p`, `wkt_q`. Optional: `split`, `case_class`, `vertices_p`, `vertices_q`, `difficulty_level`.

## Reproducibility
Use Release builds, report compiler/Boost/hardware details, run repeated trials, and report medians and interquartile ranges. Compare outputs against the published PPIBench ground truth.

## Citation
Wael Badawy, “PPIBench-V1: A Benchmark Dataset for Polygon–Polygon Intersection, Boolean Geometry, and Robust Computational Geometry,” IEEE DataPort, 29 June 2026. doi:10.21227/h3yj-6020.
